export const environment = {
    production: false,
    apiUrl: 'http://api:5000'
};