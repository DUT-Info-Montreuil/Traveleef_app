export const environment = {
    production: true,
    apiUrl: 'http://app:5000'
};